package com.dicoding.movieapp.core.domain.usecase

import androidx.lifecycle.LiveData
import com.dicoding.movieapp.core.data.Resource
import com.dicoding.movieapp.core.domain.model.Movie
import io.reactivex.Flowable

interface MovieUseCase {
    fun getAllMovie(): Flowable<Resource<List<Movie>>>
    fun getFavoriteMovie(): Flowable<List<Movie>>
    fun setFavoriteMovie(movie: Movie, state: Boolean)
}