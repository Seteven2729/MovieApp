package com.dicoding.movieapp.core.data.source.remote

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dicoding.movieapp.core.data.source.remote.network.ApiResponse
import com.dicoding.movieapp.core.data.source.remote.response.CinemaDataResponses
import com.dicoding.movieapp.core.utils.JsonHelper
import io.reactivex.BackpressureStrategy
import io.reactivex.Flowable
import io.reactivex.subjects.PublishSubject
import org.json.JSONException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RemoteDataSource @Inject constructor(private val jsonHelper: JsonHelper) {
    fun getAllMovie(): Flowable<ApiResponse<List<CinemaDataResponses>>> {
        val resultData = PublishSubject.create<ApiResponse<List<CinemaDataResponses>>>()

        //get data from local json
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            try {
                val dataArray = jsonHelper.loadData()
                resultData.onNext(if (dataArray.isNotEmpty()) ApiResponse.Success(dataArray) else ApiResponse.Empty)



            } catch (e: JSONException){
                resultData.onNext(ApiResponse.Error(e.toString()))
                Log.e("RemoteDataSource", e.toString())
            }
        }, 2000)


        return resultData.toFlowable(BackpressureStrategy.BUFFER)
    }
}

