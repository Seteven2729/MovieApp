package com.dicoding.movieapp.core.data.source.local

import com.dicoding.movieapp.core.data.source.local.entity.MovieEntity
import com.dicoding.movieapp.core.data.source.local.room.MovieDAO
import io.reactivex.Flowable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalDataSource @Inject constructor(private val movieDao: MovieDAO) {


    fun getAllMovie(): Flowable<List<MovieEntity>> = movieDao.getAllMovie()

    fun getFavoriteMovie(): Flowable<List<MovieEntity>> = movieDao.getFavoriteMovie()

    fun insertMovie(movieList: List<MovieEntity>) = movieDao.insertMovie(movieList)

    fun setFavoriteMovie(movie: MovieEntity, newState: Boolean) {
        movie.favorite= newState
        movieDao.updateFavoriteMovie(movie)
    }
}