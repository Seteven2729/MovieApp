package com.dicoding.movieapp.core.domain.usecase

import androidx.lifecycle.LiveData
import com.dicoding.movieapp.core.data.Resource
import com.dicoding.movieapp.core.domain.model.Movie
import com.dicoding.movieapp.core.domain.repository.IMovieRepository
import io.reactivex.Flowable
import javax.inject.Inject

class MovieInteractor @Inject constructor(private val movieRepository: IMovieRepository): MovieUseCase  {
    override fun getAllMovie(): Flowable<Resource<List<Movie>>> = movieRepository.getAllMovie()
    override fun getFavoriteMovie(): Flowable<List<Movie>> = movieRepository.getFavoriteMovie()
    override fun setFavoriteMovie(movie: Movie, state: Boolean) = movieRepository.setFavoriteMovie(movie,state)
}