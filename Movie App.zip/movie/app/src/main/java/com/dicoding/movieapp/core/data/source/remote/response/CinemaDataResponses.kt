package com.dicoding.movieapp.core.data.source.remote.response


data class CinemaDataResponses(
    var name: String,
    var description: String,
    var photo: Int
)

